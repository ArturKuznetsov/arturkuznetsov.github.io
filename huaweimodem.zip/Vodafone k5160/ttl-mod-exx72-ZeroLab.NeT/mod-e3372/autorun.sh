#!/system/bin/busybox sh

mkdir bin
ln -s /system/bin/sh /bin/sh

/system/sbin/NwInquire &

busybox echo 0 > /proc/sys/net/netfilter/nf_conntrack_checksum

#���ݲ���NV�����ǲ��߰汾����ֻ��wifi��������ȫӦ�ã�forgive me pls, no better method thought
ecall bsp_get_factory_mode
#BEGIN DTS2013092201594 yaozhanwei 2013-05-25 modified for wifi factory mode
dmesg | /system/bin/busybox grep "+=+=+==factory_mode+=+=+=="
#END DTS2013092201594 yaozhanwei 2013-05-25 modified for wifi factory mode
if [ $? -eq 0 ]
then
	#BEGIN DTS2013092201594 yaozhanwei 2013-05-25 added for wifi factory mode
	/system/bin/wifi_brcm/exe/wifi_poweron_factory_43241.sh
	#END DTS2013092201594 yaozhanwei 2013-05-25 added for wifi factory mode
else
	/system/bin/insmod_ctf_ko.sh
	iptables -P FORWARD DROP
	/app/appautorun.sh
	/sbin/adbd &
	busybox telnetd -l /bin/sh
fi
busybox sleep 10
iptables -t mangle -A POSTROUTING -o wan0 -j TTL --ttl-set 64
iptables -P FORWARD ACCEPT
