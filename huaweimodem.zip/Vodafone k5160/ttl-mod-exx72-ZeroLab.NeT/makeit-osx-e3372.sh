#!/bin/bash

./adb connect 192.168.8.1

./adb shell mount -o remount,rw /dev/block/mtdblock15 /system

./adb push mod-e3372/autorun.sh /system/etc
./adb shell chmod 777 /system/etc/autorun.sh

./adb shell mount -o remount,ro /dev/block/mtdblock15 /system

./adb disconnect 192.168.8.1