#!/system/bin/busybox sh



