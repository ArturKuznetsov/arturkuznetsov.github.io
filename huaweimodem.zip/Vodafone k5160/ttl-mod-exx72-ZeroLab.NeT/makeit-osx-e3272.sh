#!/bin/bash

./adb connect 192.168.1.1

./adb shell mount -o remount,rw /dev/block/mtdblock0 /system

./adb push proper/iptables /online
./adb shell chown 1049.1000 /online/iptables
./adb shell chmod 777 /online/iptables

./adb push proper/busybox /online
./adb shell chown 1049.1000 /online/busybox
./adb shell chmod 777 /online/busybox

./adb push mod-e3272/autorun.sh /system/etc
./adb shell chown 1049.1000 /system/etc/autorun.sh
./adb shell chmod 777 /system/etc/autorun.sh

./adb shell mount -o remount,ro /dev/block/mtdblock0 /system

./adb disconnect 192.168.1.1